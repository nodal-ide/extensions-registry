# Svelte Syntax Sample

This is a global language-extension pack. It requires a native grammar library and explicit trust
in Nodal IDE. The local sample includes an Apple Silicon build; rebuild it for other architectures.

The sample grammar sources used during validation were fetched from
[`tree-sitter-grammars/tree-sitter-svelte`](https://github.com/tree-sitter-grammars/tree-sitter-svelte)
at `ae5199db47757f785e43a14b332118a5474de1a2` (MIT). To rebuild, compile that source for the
current Mac architecture and replace `grammars/libtree-sitter-svelte.dylib`.

Install it from **Extensions → Add from Folder…**, open its detail, press **Trust…**, then open a
`.svelte` file. The sample covers Svelte markup and blocks plus JavaScript, TypeScript (`lang="ts"`),
CSS, and SCSS script/style zones. Disable or remove the extension to return open documents to the
built-in catalog.
