(comment) @comment

(tag_name) @tag
(attribute_name) @property
(attribute_value) @string
(raw_text) @none

[
  "as"
  "const"
  "debug"
  "else"
  "if"
  "key"
  "render"
  "snippet"
  "then"
] @keyword

[
  "await"
  "catch"
  "each"
] @repeat

[
  "#"
  ":"
  "/"
  "@"
  "{"
  "}"
] @operator
